from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline

def extract_biobert(file_path, chunk_size=512, output_file="biobert.txt"):
    #Load BioBERT model and tokenizer
    model_name = "dmis-lab/biobert-large-cased-v1.1" #a fine-tuned NER model
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForTokenClassification.from_pretrained(model_name)

    #Use pipeline for NER
    nlp = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
    
    #Reading file
    with open(file_path, 'r', encoding='utf-8') as file:
        while True:
            #Read file
            chunk = file.read(chunk_size)
            if not chunk:
                break  
            
            
            """Set max length (Fix size error)
            inputs = tokenizer(chunk, return_tensors="pt", truncation=True, padding="max_length", max_length=512)
            Perform NER 
            ner_results = nlp(inputs['input_ids'])"""
            #Perform NER 
            ner_results = nlp(chunk)
            
            print(ner_results)

            #Separate diseases and drugs
            
            diseases_chunk = []
            drugs_chunk = []

            for entity in ner_results:
                if 'entity_group' in entity:
                    # Map LABEL_0 to diseases and LABEL_1 to drugs (adjust as needed)
                    if entity['entity_group'] == 'LABEL_0':
                        diseases_chunk.append(entity['word'])
                    elif entity['entity_group'] == 'LABEL_1':
                        drugs_chunk.append(entity['word'])
                else:
                    # Handle the case where 'entity_group' field is missing
                    print(f"Warning: 'entity_group' field missing in result: {entity}")
            
            """diseases_chunk = [entity['word'] for entity in ner_results if "disease" in entity['entity'].lower()]
            drugs_chunk = [entity['word'] for entity in ner_results if "drug" in entity['entity'].lower()]"""

            save_results_to_file(diseases_chunk, drugs_chunk, output_file)

    return output_file


def save_results_to_file(diseases, drugs, output_file):
    """Append diseases and drugs to a single output file."""
    with open(output_file, 'a', encoding='utf-8') as f:
        f.write("\n--- Diseases ---\n")
        for disease in diseases:
            f.write(f"{disease}\n")
        
        f.write("\n--- Drugs ---\n")
        for drug in drugs:
            f.write(f"{drug}\n")