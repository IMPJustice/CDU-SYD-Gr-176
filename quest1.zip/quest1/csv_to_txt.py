import csv
import os

def extract_text_from_csvs(folder_path, output_file):
    csv_files = ['CSV1', 'CSV2', 'CSV3', 'CSV4']
    
    with open(output_file, 'w', encoding='utf-8') as outfile:
        for csv_file in csv_files:
            file_path = os.path.join(folder_path, f"{csv_file}.csv")
            print(f"Processing {file_path}...")
            
            if not os.path.exists(file_path):
                print(f"Warning: {file_path} does not exist. Skipping...")
                continue
            
            with open(file_path, 'r', encoding='utf-8') as infile:
                csv_reader = csv.reader(infile)
                headers = next(csv_reader)
                
                # Find the index of the column containing 'large texts'
                text_column_index = None
                for i, header in enumerate(headers):
                    if 'text' in header.lower():
                        text_column_index = i
                        break
                
                if text_column_index is None:
                    print(f"Warning: No text column found in {csv_file}. Skipping...")
                    continue
                
                for row in csv_reader:
                    if len(row) > text_column_index:
                        outfile.write(row[text_column_index] + '\n\n')

    print(f"Extraction complete. Combined text saved to {output_file}")

# Usage
folder_path = '.'  # Use current directory, or replace with the path to your CSV files
output_file = 'combined_text.txt'

extract_text_from_csvs(folder_path, output_file)