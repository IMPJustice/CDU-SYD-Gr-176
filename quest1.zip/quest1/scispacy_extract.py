import spacy

def save_results_to_file(diseases, drugs, output_file):
    with open(output_file, 'a', encoding='utf-8') as f:
        f.write("\n--- Diseases ---\n")
        for disease in diseases:
            f.write(f"{disease}\n")
        
        f.write("\n--- Drugs ---\n")
        for drug in drugs:
            f.write(f"{drug}\n")


def extract_scispacy(file_path, model_name="en_ner_bc5cdr_md", chunk_size=500000, output_file="scispacy.txt"):
    #Load the en_ner_bc5cdr_md model
    nlp = spacy.load(model_name)
    
    #Increase length limit
    nlp.max_length = chunk_size + 100000
    
    #Reading file
    with open(file_path, 'r', encoding='utf-8') as file:
        while True:
            # Read chunk from file
            chunk = file.read(chunk_size)
            if not chunk:
                break

            #Process the chunk
            doc = nlp(chunk)

            #Separate into diseases and drugs
            diseases_chunk = []
            drugs_chunk = []
            
            for ent in doc.ents:
                if ent.label_ == "DISEASE":
                    diseases_chunk.append(ent.text)
                elif ent.label_ == "CHEMICAL":
                    drugs_chunk.append(ent.text)
                else:
                    print(f"Found entity '{ent.text}' with unhandled label '{ent.label_}'")

            print(f"Chunk processed: {len(diseases_chunk)} diseases and {len(drugs_chunk)} drugs found.")
    
            # Save results incrementally
            save_results_to_file(diseases_chunk, drugs_chunk, output_file)
    
    return output_file
