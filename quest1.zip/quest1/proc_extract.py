from scispacy_extract import extract_scispacy
from biobert_extract import extract_biobert
from comparison import compare_ent
import os

def process(file_path):

    #Check File
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f'The file at {file_path} does not existed or not to be found')
    
    try:
        #Process the file in chunks using SciSpaCy (results are saved incrementally)
        scispacy_output_file = extract_scispacy(file_path)

        #Process the file in chunks using BioBERT (results are saved incrementally)
        biobert_output_file = extract_biobert(file_path)
    except PermissionError as e:
        raise PermissionError(f"Permission denied: {e}")
    

    return {
        "scispacy_file": scispacy_output_file,
        #"biobert_file": biobert_output_file
    }
    

def result_output(file_path):

    results = process(file_path)

    # Print SciSpaCy results
    print("\n--- SciSpaCy Results ---")
    print(f"Results saved to: {results['scispacy_file']}")


    # Print BioBERT results
    print("\n--- BioBERT Results ---")
    print(f"Results saved to: {results['biobert_file']}")
    
    #Comparison
    compare_results(file_path, results)


def compare_results(file_path, results):
    #Read SciSpaCy results
    with open(results['scispacy_file'], 'r') as scispacy_file:
        scispacy_data = scispacy_file.read().splitlines()
    scispacy_diseases = scispacy_data[scispacy_data.index("--- Diseases ---") + 1:scispacy_data.index("--- Drugs ---")]
    scispacy_drugs = scispacy_data[scispacy_data.index("--- Drugs ---") + 1:]

    #Read BioBERT results
    with open(results['biobert_file'], 'r') as biobert_file:
        biobert_data = biobert_file.read().splitlines()
    biobert_diseases = biobert_data[biobert_data.index("--- Diseases ---") + 1:biobert_data.index("--- Drugs ---")]
    biobert_drugs = biobert_data[biobert_data.index("--- Drugs ---") + 1:]

    #Perform the comparison
    comparison = compare_ent(
        (scispacy_diseases, scispacy_drugs),
        (biobert_diseases, biobert_drugs)
    )
    
    with open("comparison_results.txt", 'w', encoding='utf-8') as f:
        print("\n--- Comparison Results ---")
        print(f"Total SciSpaCy entities: {comparison['total_scispacy']}")
        print(f"Total BioBERT entities: {comparison['total_biobert']}")
        print(f"Common diseases: {comparison['common_diseases']}")
        print(f"Common drugs: {comparison['common_drugs']}")
        print(f"Different diseases: {comparison['diff_diseases']}")
        print(f"Different drugs: {comparison['diff_drugs']}")
        print(f"Most common SciSpaCy entities: {comparison['most_common_scispacy']}")
        print(f"Most common BioBERT entities: {comparison['most_common_biobert']}")
        
    print("\n--- Comparison Results ---")
    print(f"Comparison results saved to 'comparison_results.txt'")