from collections import Counter

def compare_ent(scispacy_ent, biobert_ent):
    #Total Drug and Disease detected by each model
    total_scispacy = len(scispacy_ent[0]) + len(scispacy_ent[1])
    total_biobert = len(biobert_ent[0]) + len(biobert_ent[1])
    
    #Similar Drug and Diseases between the two models
    common_diseases = set(scispacy_ent[0]).intersection(set(biobert_ent[0]))
    common_drugs = set(scispacy_ent[1]).intersection(set(biobert_ent[1]))

    #Different Drug and Diseases detection
    diff_diseases = set(scispacy_ent[0]).symmetric_difference(set(biobert_ent[0]))
    diff_drugs = set(scispacy_ent[1]).symmetric_difference(set(biobert_ent[1]))

    #Drug and Disease in both .txt
    most_common_scispacy = Counter(scispacy_ent[0] + scispacy_ent[1]).most_common(10)
    most_common_biobert = Counter(biobert_ent[0] + biobert_ent[1]).most_common(10)

    #Results
    return {
        "total_scispacy": total_scispacy,
        "total_biobert": total_biobert,
        "common_diseases": common_diseases,
        "common_drugs": common_drugs,
        "diff_diseases": diff_diseases,
        "diff_drugs": diff_drugs,
        "most_common_scispacy": most_common_scispacy,
        "most_common_biobert": most_common_biobert,
    }
